import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {parseHTML} from 'linkedom';

// The published Wix HTML is retained as migration evidence, outside site/.
// Only cleaned static HTML, CSS, media and our small replacement script ship.
const origin='https://yixuans.wixsite.com/home';
const target='https://ee-shuan-song.github.io';
const pages=[['home',''],['about','about'],['publications','publications'],['research-blog','research-blog'],['portfolio','portfolio'],['post','post/template-how-to-write-a-recipe-post-2'],['category','research-blog/categories/fun'],['tag-3d','research-blog/tags/3d-printing'],['tag-surprise','research-blog/tags/surprise'],...[1,3,5,6].map(n=>['project-'+n,'portfolio-collections/my-portfolio/project-title-'+n])];
const assetMap=new Map();
const deferredVideoIds=JSON.parse(fs.readFileSync('migration/deferred-media.json','utf8')).videoIds;
fs.mkdirSync('site/assets',{recursive:true});
function register(input){
  let url=input.startsWith('//')?'https:'+input:input;
  if(!/^https?:/.test(url))return input;
  // Replace Wix's blurred placeholders with the original, full-resolution media.
  if(url.startsWith('https://static.wixstatic.com/media/')&&url.includes('blur_2')){
    const base=url.split('/v1/')[0];
    const isLab=base.includes('d9113050');
    url=base+`/v1/fill/w_${isLab?1920:1300},h_${isLab?1350:914},al_c,q_90/`+path.basename(new URL(base).pathname);
  }
  url=url.replace(/&amp;/g,'&');
  if(!assetMap.has(url)){
    const ext=path.extname(new URL(url).pathname)||'.bin';
    const stem=path.basename(new URL(url).pathname,ext).replace(/[^a-zA-Z0-9_-]/g,'-').slice(0,65)||'asset';
    assetMap.set(url,`${stem}-${crypto.createHash('sha256').update(url).digest('hex').slice(0,10)}${ext}`);
  }
  return '/assets/'+assetMap.get(url);
}
function cssAssets(css){
  // Banner fonts are not part of the user's design.
  css=css.replace(/@font-face\s*\{[^}]*wixFreemium[^}]*\}/g,'');
  return css.replace(/url\(\s*(['"]?)(https?:\/\/[^)'"\s]+|\/\/[^)'"\s]+)\1\s*\)/g,(_,q,url)=>`url("${register(url)}")`);
}
const manifest=[];
for(const variant of ['desktop','mobile'])for(const [name,route] of pages){
  const mobile=variant==='mobile';
  const {document:d}=parseHTML(fs.readFileSync(`migration/source/${mobile?'mobile/':''}wix-${name}.html`,'utf8'));
  for(const el of d.querySelectorAll('script,noscript,base,link,#WIX_ADS,#SKIP_TO_CONTENT_BTN'))el.remove();
  for(const el of d.querySelectorAll('meta')){
    if(!['charset','viewport','description','theme-color'].some(k=>el.hasAttribute(k)||el.getAttribute('name')===k))el.remove();
  }
  d.documentElement.setAttribute('lang','en');
  d.body.setAttribute('data-page',name);
  d.body.setAttribute('data-variant',variant);
  for(const el of d.querySelectorAll('*')){
    for(const attr of [...el.attributes]){
      if(/^on/i.test(attr.name)||attr.name==='data-video-info'||attr.name.toLowerCase()==='srcset')el.removeAttribute(attr.name);
    }
    if(el.hasAttribute('style'))el.setAttribute('style',cssAssets(el.getAttribute('style')));
  }
  for(const more of d.querySelectorAll('li[data-index="__more__"]'))more.remove();
  for(const style of d.querySelectorAll('style'))style.textContent=cssAssets(style.textContent);
  for(const img of d.querySelectorAll('img')){
    const src=img.getAttribute('src');
    if(src?.startsWith('https:'))img.setAttribute('src',register(src));
    img.removeAttribute('srcset');img.removeAttribute('sizes');
    img.setAttribute('decoding','async');
  }
  for(const source of d.querySelectorAll('picture source'))source.remove();
  for(const frame of d.querySelectorAll('iframe')){
    const src=frame.getAttribute('src');
    if(src?.includes('video.wixstatic.com')){
      const poster=frame.closest('.gallery-item-container')?.querySelector('img[data-hook="gallery-item-image-img"],img')?.getAttribute('src');
      if(deferredVideoIds.some(id=>src.includes(id))){
        const placeholder=d.createElement('div');placeholder.setAttribute('class','gallery-item-content video-placeholder');placeholder.setAttribute('style',frame.getAttribute('style')||'');
        if(poster){const img=d.createElement('img');img.setAttribute('src',poster);img.setAttribute('alt','Disaggregation experiment video cover');placeholder.append(img);}
        const note=d.createElement('span');note.textContent='Video coming soon';placeholder.append(note);frame.replaceWith(placeholder);continue;
      }
      const video=d.createElement('video');video.setAttribute('controls','');video.setAttribute('playsinline','');video.setAttribute('preload','metadata');
      if(poster)video.setAttribute('poster',poster);
      video.setAttribute('src',register(src));video.setAttribute('class',frame.getAttribute('class')||'');
      video.setAttribute('style',frame.getAttribute('style')||'');frame.replaceWith(video);
    }else frame.remove();
  }
  for(const a of d.querySelectorAll('a[href]')){
    const href=a.getAttribute('href');
    if(href.startsWith(origin)){
      const url=new URL(href);const suffix=url.pathname.slice('/home'.length).replace(/^\//,'');
      a.setAttribute('href','/'+suffix+(suffix?'/':'')+url.hash);
      const anchor=a.getAttribute('data-anchor');
      if(anchor)a.setAttribute('href','/'+suffix+(suffix?'/':'')+'#'+anchor);
      if(a.textContent.trim()==='Contact')a.setAttribute('href','#contact');
    }else if(/\.filesusr\.com\/ugd\/.+\.pdf/.test(href))a.setAttribute('href',register(href));
    if(href==='https://www.linkedin.com/company/wix-com')a.setAttribute('href','https://www.linkedin.com/in/biuxiu/');
    if(a.getAttribute('aria-label')==='Search')a.setAttribute('href','/research-blog/?search=1');
    if(href.includes('wix.com/templateslp/links')){
      const block=a.closest('.wixui-rich-text')||a.parentElement;
      const text=block.textContent;
      const doi=text.includes('2023')?'10.3389/fmars.2023.1224518':text.includes('2022')?'10.1002/lom3.10509':text.includes('2020')?'10.1063/1.5144415':null;
      if(doi)a.setAttribute('href','https://doi.org/'+doi);
    }
    if(a.getAttribute('target')==='_blank')a.setAttribute('rel','noopener noreferrer');
  }
  const footer=d.querySelector('#SITE_FOOTER');
  if(footer){
    const marker=d.createElement('span');marker.id='contact';footer.prepend(marker);
    const wix=footer.querySelector('a[href*="wix.com"]');
    if(wix){const p=wix.closest('p');if(p)p.innerHTML='<span>©2023 by Yixuan Song.</span>';}
  }
  for(const form of d.querySelectorAll('form')){
    form.setAttribute('data-contact-form','');form.setAttribute('action','mailto:yixuan.song@uri.edu');
    form.setAttribute('method','get');
    for(const captcha of form.querySelectorAll('[data-testid*="captcha"],.wixui-captcha'))captcha.remove();
    const email=form.querySelector('input[type=email]');if(email)email.setAttribute('required','');
    const submit=form.querySelector('button');
    if(submit){submit.removeAttribute('disabled');submit.setAttribute('type','submit');submit.setAttribute('aria-label','Open Email');const label=submit.querySelector('[data-testid="button__label"]')||submit.querySelector('span');if(label)label.textContent='Open Email';else submit.textContent='Open Email';}
    const note=d.createElement('p');note.className='contact-note';note.setAttribute('role','status');note.textContent='Opens your email app to send your message. You can also email yixuan.song@uri.edu directly.';form.append(note);
  }
  if(name.startsWith('project-')){
    const order=[1,3,5,6];const pos=order.indexOf(Number(name.split('-')[1]));
    for(const button of d.querySelectorAll('button[aria-label="Previous Project"],button[aria-label="Next Project"]')){
      const offset=button.getAttribute('aria-label')==='Next Project'?1:-1;
      const next=order[(pos+offset+order.length)%order.length];
      button.setAttribute('data-go',`/portfolio-collections/my-portfolio/project-title-${next}/`);
    }
  }
  const canonical=d.createElement('link');canonical.setAttribute('rel','canonical');canonical.setAttribute('href',target+'/'+route+(route?'/':''));d.head.append(canonical);
  const icon=d.createElement('link');icon.setAttribute('rel','icon');icon.setAttribute('href','/favicon.svg');d.head.append(icon);
  const css=d.createElement('link');css.setAttribute('rel','stylesheet');css.setAttribute('href','/migration.css');d.head.append(css);
  const js=d.createElement('script');js.setAttribute('defer','');js.setAttribute('src','/site.js');d.body.append(js);
  if(mobile){const noindex=d.createElement('meta');noindex.setAttribute('name','robots');noindex.setAttribute('content','noindex');d.head.append(noindex);}
  const dir=path.join('site',mobile?'_mobile':'',route);fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'index.html'),'<!doctype html>\n'+d.documentElement.outerHTML);
  if(!mobile)manifest.push({source:origin+(route?'/'+route:''),route:'/'+route+(route?'/':''),title:d.title});
}
// Download each original only once. Existing files make reruns independent of Wix.
const queue=[...assetMap];let done=0;const failures=[];
await Promise.all(Array.from({length:6},async()=>{
  while(queue.length){const [url,file]=queue.shift();const local='site/assets/'+file;
    if(fs.existsSync(local)&&fs.statSync(local).size){done++;continue;}
    try{const res=await fetch(url,{signal:AbortSignal.timeout(120000)});if(!res.ok)throw Error('HTTP '+res.status);const bytes=Buffer.from(await res.arrayBuffer());fs.writeFileSync(local,bytes);done++;if(done%20===0)console.log(`Saved ${done}/${assetMap.size} assets`);}
    catch(e){failures.push({url,error:e.message});}
  }
}));
fs.writeFileSync('migration/manifest.json',JSON.stringify({origin,target,pages:manifest,assets:[...assetMap].map(([url,file])=>({url,file})),failures},null,2));
const retained=new Set(assetMap.values());
for(const file of fs.readdirSync('site/assets'))if(!retained.has(file))fs.unlinkSync('site/assets/'+file);
fs.writeFileSync('site/.nojekyll','');
fs.writeFileSync('site/robots.txt',`User-agent: *\nAllow: /\nSitemap: ${target}/sitemap.xml\n`);
fs.writeFileSync('site/sitemap.xml',`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${manifest.map(p=>`<url><loc>${target}${p.route}</loc></url>`).join('')}</urlset>`);
console.log(JSON.stringify({pages:pages.length,assets:assetMap.size,failures},null,2));
if(failures.length)process.exitCode=1;
