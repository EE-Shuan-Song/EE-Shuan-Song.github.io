import fs from 'node:fs';
import path from 'node:path';
import {parseHTML} from 'linkedom';
const data=JSON.parse(fs.readFileSync('content/publications.json','utf8'));
const cv='/documents/Yixuan-Song-CV.pdf';
const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const authors=s=>escape(s).replaceAll('Y. Song','<strong>Y. Song</strong>');
function citation(p){return `<p class="publication-authors">${authors(p.authors)} (${p.year}).</p><p class="publication-paper"><a href="https://doi.org/${escape(p.doi)}">${escape(p.title)}.</a></p><p class="publication-journal"><em>${escape(p.journal)}</em>, ${escape(p.details)}.</p><p class="publication-doi"><a href="https://doi.org/${escape(p.doi)}">doi: ${escape(p.doi)}</a>${p.type?` <span class="publication-type">${escape(p.type)}</span>`:''}</p>`;}
const years=[...new Set(data.published.map(p=>p.year))];
const published=years.map(year=>`<section class="publication-year" aria-label="${year} publications"><h2>${year}</h2><div>${data.published.filter(p=>p.year===year).map(p=>`<article class="publication-entry">${citation(p)}</article>`).join('')}</div></section>`).join('');
const manuscripts=data.manuscripts.map(p=>`<article class="publication-entry manuscript-entry"><p class="publication-status">${escape(p.status)}</p><p class="publication-authors">${authors(p.authors)}.</p><p>${escape(p.title)}.</p>${p.doi?`<p class="publication-doi"><a href="https://doi.org/${escape(p.doi)}">${escape(p.linkLabel)} · doi: ${escape(p.doi)}</a></p>`:''}</article>`).join('');
for(const mobile of [false,true]){
  const file=path.join('site',mobile?'_mobile':'','publications/index.html');
  const {document:d}=parseHTML(fs.readFileSync(file,'utf8'));
  d.querySelector('#PAGES_CONTAINER').innerHTML=`<section class="publications-page"><div class="publications-intro"><h1>Publications</h1><a class="cv-download" href="${cv}" target="_blank" rel="noopener">Download CV (PDF)</a></div><p class="publications-subtitle">Journal articles and conference papers</p>${published}<section class="manuscripts-section" aria-labelledby="manuscripts-heading"><h2 id="manuscripts-heading">Preprints and manuscripts</h2>${manuscripts}</section></section>`;
  d.title='Publications | Yixuan Song';
  fs.writeFileSync(file,'<!doctype html>\n'+d.documentElement.outerHTML);
  const home=path.join('site',mobile?'_mobile':'','index.html');
  const {document:h}=parseHTML(fs.readFileSync(home,'utf8'));
  const ids=['comp-kgrzmugj','comp-kgrznuyr','comp-kgrznxfr'];
  ids.forEach((id,i)=>{
    const p=data.published[i];const el=h.getElementById(id);
    el.innerHTML=`<p class="font_7 wixui-rich-text__text">${authors(p.authors)} (${p.year}). ${escape(p.title)}. <em>${escape(p.journal)}</em>, ${escape(p.details)}.<br><a href="https://doi.org/${escape(p.doi)}">doi: ${escape(p.doi)}</a></p>`;
  });
  h.querySelector('[data-mesh-id="comp-ki8ym19jinlineContent-gridContainer"]')?.classList.add('home-publications-list');
  fs.writeFileSync(home,'<!doctype html>\n'+h.documentElement.outerHTML);
}
function htmlFiles(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(x=>x.isDirectory()?htmlFiles(path.join(dir,x.name)):x.name.endsWith('.html')?[path.join(dir,x.name)]:[]);}
for(const file of htmlFiles('site')){
  const {document:d}=parseHTML(fs.readFileSync(file,'utf8'));let changed=false;
  for(const a of d.querySelectorAll('a[href]'))if(a.textContent.trim()==='Curriculum Vitae'||a.getAttribute('href').includes('944f85_1b8666c4dcb847b3a3697894c1e3c7b6')){
    a.setAttribute('href',cv);a.setAttribute('target','_blank');a.setAttribute('rel','noopener');changed=true;
  }
  if(changed)fs.writeFileSync(file,'<!doctype html>\n'+d.documentElement.outerHTML);
}
const manifest=JSON.parse(fs.readFileSync('migration/manifest.json','utf8'));
const obsolete=manifest.assets.filter(x=>x.file.endsWith('.pdf'));
manifest.assets=manifest.assets.filter(x=>!x.file.endsWith('.pdf'));
for(const a of obsolete){const file='site/assets/'+a.file;if(fs.existsSync(file))fs.unlinkSync(file);}
manifest.documents=[{file:'documents/Yixuan-Song-CV.pdf',source:'November 2026 CV; public copy excludes personal phone, references, and grants/funding.'}];
fs.writeFileSync('migration/manifest.json',JSON.stringify(manifest,null,2));
console.log(`Updated ${data.published.length} published papers, ${data.manuscripts.length} manuscripts and public CV links.`);
