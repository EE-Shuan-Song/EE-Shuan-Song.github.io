// All interactions run locally; there are no Wix runtime or analytics requests.
(async()=>{
if(matchMedia('(max-width: 767px)').matches&&document.body.dataset.variant!=='mobile'){
  try{
    const response=await fetch('/_mobile'+location.pathname+(location.pathname.endsWith('/')?'index.html':'/index.html'));
    if(!response.ok)throw Error('Mobile layout unavailable');
    const mobile=new DOMParser().parseFromString(await response.text(),'text/html');
    document.head.querySelectorAll('style,link[rel=stylesheet]').forEach(el=>el.remove());
    mobile.head.querySelectorAll('style,link[rel=stylesheet]').forEach(el=>document.head.append(document.importNode(el,true)));
    document.body.replaceWith(document.importNode(mobile.body,true));
    document.querySelector('meta[name=viewport]').content='width=320, user-scalable=yes';
  }catch(error){console.warn(error.message)}
}
const menuToggle=document.querySelector('#MENU_AS_CONTAINER_TOGGLE');
if(menuToggle){
  const menu=document.createElement('dialog');menu.className='mobile-nav';menu.setAttribute('aria-label','Navigation');
  const close=document.createElement('button');close.textContent='×';close.setAttribute('aria-label','Close navigation');
  const nav=document.createElement('nav');nav.setAttribute('aria-label','Site');
  document.querySelectorAll('#MENU_AS_CONTAINER_EXPANDABLE_MENU a').forEach(a=>{const link=document.createElement('a');link.href=a.getAttribute('href');link.textContent=a.textContent;nav.append(link)});
  menu.append(close,nav);document.body.append(menu);
  const open=()=>{menu.showModal();menuToggle.setAttribute('aria-expanded','true')};
  menuToggle.addEventListener('click',open);menuToggle.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();open()}});
  close.onclick=()=>menu.close();menu.addEventListener('close',()=>menuToggle.setAttribute('aria-expanded','false'));
  nav.addEventListener('click',()=>menu.close());
}
function layoutPortfolio(){
  if(document.body.dataset.page!=='portfolio')return;
  document.querySelectorAll('.pro-gallery-margin-container').forEach(container=>{
    const width=container.clientWidth;const mobile=document.body.dataset.variant==='mobile';
    const cols=mobile?1:3;const gap=mobile?20:40;const size=(width-gap*(cols-1))/cols;
    const items=[...container.querySelectorAll('.gallery-item-container')];
    const height=Math.ceil(items.length/cols)*(size+gap)-gap;
    container.style.height=height+'px';container.parentElement.style.height=height+'px';
    items.forEach((item,i)=>{
      Object.assign(item.style,{width:size+'px',height:size+'px',left:(i%cols)*(size+gap)+'px',top:Math.floor(i/cols)*(size+gap)+'px'});
      item.querySelectorAll('.gallery-item-wrapper,.gallery-item-content,.item-hover-flex-container,.gallery-item-hover').forEach(el=>{el.style.width=size+'px';el.style.height=size+'px'});
    });
  });
}
layoutPortfolio();window.addEventListener('resize',layoutPortfolio);
document.querySelectorAll('[data-go]').forEach(el=>el.addEventListener('click',()=>location.assign(el.dataset.go)));
document.querySelectorAll('[data-contact-form]').forEach(form=>{
  form.addEventListener('submit',event=>{
    event.preventDefault();if(!form.reportValidity())return;
    const data=new FormData(form);
    const first=data.get('first-name')||'';const last=data.get('last-name')||'';
    const fields=[...form.querySelectorAll('input,textarea')];
    const email=fields.find(x=>x.type==='email')?.value||'';
    const subject=fields.find(x=>/subject/i.test(x.name))?.value||'Website message';
    const message=form.querySelector('textarea')?.value||'';
    const body=`${message}\n\nFrom: ${first} ${last}\nEmail: ${email}`;
    form.querySelector('.contact-note').textContent='Your email app will open. Send the message there, or email yixuan.song@uri.edu directly.';
    location.href=`mailto:yixuan.song@uri.edu?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  });
});
// Restore image enlargement without a proprietary gallery service.
function openImage(img){
  const dialog=document.createElement('dialog');dialog.className='photo-dialog';const close=document.createElement('button');close.textContent='×';close.setAttribute('aria-label','Close image');const full=document.createElement('img');full.src=img.src;full.alt=img.alt;dialog.append(close,full);document.body.append(dialog);close.onclick=()=>dialog.close();dialog.addEventListener('close',()=>dialog.remove());dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});dialog.showModal();
}
document.querySelectorAll('.gallery-item-container').forEach(item=>{
  const img=item.querySelector('img[data-hook="gallery-item-image-img"],img');
  if(!img||item.closest('a')||item.querySelector('video'))return;
  item.tabIndex=0;item.setAttribute('role','button');item.setAttribute('aria-label',`Enlarge ${img.alt||'image'}`);
  item.addEventListener('click',()=>openImage(img));item.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openImage(img)}});
});
document.querySelectorAll('button[aria-label="Expand image"]').forEach(button=>button.addEventListener('click',()=>{const img=button.closest('[data-hook="image-viewer"]')?.querySelector('img');if(img)openImage(img)}));
// The source blog has one published post; search filters its existing card.
function openSearch(anchor){
  if(document.querySelector('.local-search'))return;
  const input=document.createElement('input');input.className='local-search';input.type='search';input.placeholder='Search posts';input.setAttribute('aria-label','Search posts');anchor.before(input);input.focus();
  input.addEventListener('input',()=>{document.querySelectorAll('[data-hook="post"]').forEach(card=>card.hidden=!card.textContent.toLowerCase().includes(input.value.toLowerCase()))});
}
document.querySelectorAll('button[aria-label="Search"],[role="button"][aria-label="Search"]').forEach(button=>{
  button.addEventListener('click',()=>openSearch(button));
  if(button.tagName!=='BUTTON')button.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openSearch(button)}});
});
if(new URLSearchParams(location.search).has('search')){const list=document.querySelector('[data-hook="post-list"]');if(list)openSearch(list);}
document.querySelectorAll('button[aria-label="More actions"]').forEach(button=>button.addEventListener('click',()=>{
  const actions=button.closest('[data-hook="post"]')?.querySelector('[data-hook="post-main-actions-desktop"]')||document.querySelector('[data-hook="post-main-actions-desktop"]');
  if(!actions)return;
  const dialog=document.createElement('dialog');dialog.className='share-dialog';dialog.setAttribute('aria-label','Share this post');
  const close=document.createElement('button');close.textContent='Close';close.onclick=()=>dialog.close();
  const title=document.createElement('p');title.textContent='Share this post';dialog.append(title,actions.cloneNode(true),close);document.body.append(dialog);dialog.addEventListener('close',()=>dialog.remove());dialog.showModal();
}));
document.addEventListener('click',async event=>{
  const button=event.target.closest('button[aria-label^="Share via"]');if(!button)return;
  const post=button.closest('[data-hook="post"]');
  const path=post?.querySelector('a[href*="/post/"]')?.getAttribute('href')||'/post/template-how-to-write-a-recipe-post-2/';
  const url=new URL(path,location.origin).href;const encoded=encodeURIComponent(url);const label=button.getAttribute('aria-label');
  if(label==='Share via link'){
    try{await navigator.clipboard.writeText(url);button.setAttribute('aria-label','Link copied');const status=document.createElement('span');status.setAttribute('role','status');status.textContent='Link copied';button.after(status)}catch{window.prompt('Copy this link',url)}
    return;
  }
  const destinations={'Share via Facebook':`https://www.facebook.com/sharer/sharer.php?u=${encoded}`,'Share via X (Twitter)':`https://twitter.com/intent/tweet?url=${encoded}`,'Share via LinkedIn':`https://www.linkedin.com/sharing/share-offsite/?url=${encoded}`};
  if(destinations[label])window.open(destinations[label],'_blank','noopener,noreferrer');
});
})();
